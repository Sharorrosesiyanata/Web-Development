const ContactPage = () => {
    return (
        <div> 
            <h1>Contact Page</h1>
            <p>Phone: 555-555-5555</p>
        </div>
        )
};

export default ContactPage;
