'use client';

export const metadata = {
    title: "Library Of Knowledge",
    description: "Mental Knowledge and Refrences",
    keywords: "skill acquiring, educational courses, education books",
};

const AboutPage = () => {
    return (
        <div>
            About Page
        </div>
    )
};

export default AboutPage;
