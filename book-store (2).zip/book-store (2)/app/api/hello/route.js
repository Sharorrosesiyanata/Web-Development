export async function POST(req) {
    return new Response('Hello World!');
}