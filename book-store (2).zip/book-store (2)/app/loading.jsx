const LoadingPage = () => {
    return (
        <div>
            <button className="btn loading">loading</button>
        </div>
    )
};

export default LoadingPage;
