import Books from './components/Books';

const HomePage = () => {
  return (
    <div>
      <Books/>
    </div>
    
  )
};
export default HomePage;
